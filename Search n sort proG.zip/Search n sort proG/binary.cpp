#include<iostream>
using namespace std;
int main()
{
	int arr[15],i,n,s;

	printf("\nEnter number of elements for array: ");
	scanf("%d",&n);
	if(n==0)
	{
		printf("\nInvalid input....array must contain some elements");
		printf("\nAgain enter number of element for array: ");
		scanf("%d",&n);
	}
    
    printf("\nEnter elements for array (in sorted order): ");
    for(i=0;i<n;i++)
    {
    	scanf("%d",&arr[i]);
    	
	}
	printf("\nYour array contains: ");
	
	for(i=0;i<n;++i)
	printf("%d ",arr[i]);
	
	printf("\nEnter element to be searcher for: ");
	scanf("%d",&s);
	
	int beg=0,end=n-1,mid,flag=0;
	
	while(beg<=end)
	{
		mid=(beg+end)/2;
		if(s==arr[mid])
		{
			printf("\nElemet found at position:%d ",mid+1);
			flag=1;
			break;
		}
		else if(s<arr[mid])
		{
			end=mid-1;
		}
		else
		  beg=mid+1;
		  
	}
    
    if(flag==0)
    {
    	printf("\nElement does not found in array");
	}
	
	return 0;
}

