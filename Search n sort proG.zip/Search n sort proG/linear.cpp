#include<iostream>
using namespace std;
int main()
{
	int arr[30],n,s,i,flag=0;
	printf("Enter number of elements: ");
	scanf("%d",&n);
	if(n==0)
	{
		printf("\ninvalid input ......array must contain something");
		printf("\n\nAgain enter number of elements for array: ");
		scanf("%d",&n);
			}
	//loop for input element from user
	
	printf("\nEnter elements for array: ");
	for(i=0;i<n;++i)
	{
	scanf("%d",&arr[i]);
	}
	
	printf("\nYour array contains: ");
	//Display array
	
	for(i=0;i<n;++i)
	printf("%d ",arr[i]);
	
	printf("\n\nEnter element to be searched for: ");
	scanf("%d",&s);
	//loop for searching element
	
	for(i=0;i<n;++i)
		if(s==arr[i])
		{
			printf("\nElement is found at:%d",i+1);
			flag=1;
			break;
		}
	
		if(flag==0)
		printf("\nElement does not found in array");
		
		return 0;

	
}
