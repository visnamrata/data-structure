#include<iostream>
using namespace std;
int main()
{
	int arr[15],n,i;
	printf("Enter nmber of element for array: ");
	scanf("%d",&n);
	printf("\nEnter elements for array: ");
	for(i=0;i<n;++i)
	{
		scanf("%d",&arr[i]);
		
	}
	int j,key;
	for(i=1;i<n;++i)
	{   
	  key=arr[i];
	  j=i-1;
	
		while(j>=0&&arr[j]>key)
		{
			arr[j+1]=arr[j];
			--j;
		}
		arr[j+1]=key;
	}
	printf("\nSorted array: ");
	for(i=0;i<n;++i)
	{   
	  
		printf("%d ",arr[i]);
	}
	
	return 0;
}

